module.exports = {
    name: "耕读文化园",
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "1.6.5",
  siteroot: "https://guohainc.cnderui.com/app/index.php",
    design_method: "3"
};