Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        bgColor: {
            type: String,
            value: "#fff"
        },
        height: {
            type: Number,
            value: 20
        }
    }
});