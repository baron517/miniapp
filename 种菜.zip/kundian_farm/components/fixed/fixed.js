Component({
    properties: {
        bottom: {
            type: Number,
            value: 1
        },
        left: {
            type: Number,
            value: 100
        },
        opacity: {
            type: Number,
            value: 0
        },
        bgColor: {
            type: String,
            value: "#808080"
        },
        img: {
            type: String,
            value: ""
        }
    }
});