Component({
    properties: {
        parma: {
            type: Object,
            value: {}
        }
    }
});