Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        styles: {
            type: String,
            value: "solid"
        },
        lineColor: {
            type: String,
            value: "#000"
        },
        bgColor: {
            type: String,
            value: "#000"
        },
        lineHeight: {
            type: Number,
            value: .5
        },
        height: {
            type: Number,
            value: 0
        }
    }
});