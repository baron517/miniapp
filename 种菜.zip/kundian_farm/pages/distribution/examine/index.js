Page({
    data: {
        farmSetData: wx.getStorageSync("kundian_farm_setData")
    },
    onLoad: function(a) {}
});