var api = require("../../api.js"), app = getApp();

Page({
    data: {},
    onLoad: function(n) {
        app.pageOnLoad(this, n);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});